# Generador PDF

Generador de un archivo PDF a partir de un Excel e imágenes de un catálogo de productos.
Hecho en JavaFX.

Ejecutar: mvn compile clean javafx:run

Compilar shaded JAR: mvn clean install